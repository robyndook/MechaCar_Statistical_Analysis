# Dataset: sardine.dat

Source: F.N. Clark (1936). "Variations in the Number of Vertebrae in Sardine,
Sardinops caerulea (Girard)", Copeia, Vol. 1936, #3, pp.147-150.

Description: Number of Vertebrae and Location of 12858 adult sardines caught
in the Pacific.

Locations:
1=Alaska
2=British Columbia
3=San Francisco
4=Monterey
5=San Pedro
6=San Diego

Variables/Columns
Location   8
Number of Vertebrae   15-16
