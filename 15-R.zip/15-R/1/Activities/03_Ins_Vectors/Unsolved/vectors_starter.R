library(dplyr)

# Simple vectors
# Months of the year


# Average rainfall/precipitation in NYC during each month

# Assign names to a vector
# Assign months to precipitation as names


# Display precipitation


# Display names of precipitation


# Access a single member of precipitation by its name


# Summary of data
# Display summary data of precipitation

# Store the results in a vector.

# Access features of a summary

# Use double brackets to access only the value


# Use pipe operators to express a sequence of operations


# Use double brackets to access only the value

# Standard deviation
# Display the standard deviation 


# Round SD to two digits


# Standard deviation and round using the pipe operator


# A few more methods
# Determine the length of a vector


# Display the sum of a vector


# The same operations, this time using pipes



